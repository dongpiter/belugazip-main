import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import AdminLayout from "@/components/AdminLayout";
import { useListAdminMenus, useCreateMenu, useUpdateMenu } from "@workspace/api-client-react";
import { Plus, Trash2, Loader2, ChevronLeft } from "lucide-react";
import { toast } from "sonner";
import { Link } from "wouter";

type Dish = { name: string; description: string };
type FAQ = { q: string; a: string };
type MenuRow = { id: string; name: string; slug: string; description?: string | null; long_description?: string | null; price_per_person: number; image_url?: string | null; banner_url?: string | null; category: string; is_active?: boolean | null; is_featured?: boolean | null; tag?: string | null; target_audience?: string | null; min_guests?: number | null; dishes?: Dish[] | null; nutrition_calories?: number | null; nutrition_protein?: number | null; nutrition_fat?: number | null; nutrition_carbs?: number | null; faqs?: FAQ[] | null; seo_metadata?: { meta_title?: string; meta_description?: string } | null };

const categoryOptions = [
  { value: "office", label: "Văn phòng" },
  { value: "event", label: "Sự kiện" },
  { value: "vegan", label: "Chay" },
  { value: "teabreak", label: "Teabreak" },
  { value: "buffet", label: "Buffet" },
];

function slugify(text: string) {
  return text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

export default function MenuForm() {
  const { id } = useParams<{ id: string }>();
  const isEdit = !!id && id !== "new";
  const [, navigate] = useLocation();

  const { data: allMenus } = useListAdminMenus();
  const existingMenu = isEdit ? (allMenus as MenuRow[] | undefined)?.find((m) => m.id === id) : undefined;

  const [form, setForm] = useState({
    name: "", slug: "", description: "", long_description: "", tag: "", target_audience: "",
    price_per_person: 95000, image_url: "", banner_url: "", category: "office",
    is_active: true, is_featured: false, min_guests: 10,
    nutrition_calories: 400, nutrition_protein: 30, nutrition_fat: 12, nutrition_carbs: 45,
    meta_title: "", meta_description: "",
  });
  const [dishes, setDishes] = useState<Dish[]>([{ name: "", description: "" }]);
  const [faqs, setFaqs] = useState<FAQ[]>([{ q: "", a: "" }]);

  useEffect(() => {
    if (existingMenu) {
      setForm({
        name: existingMenu.name ?? "",
        slug: existingMenu.slug ?? "",
        description: existingMenu.description ?? "",
        long_description: existingMenu.long_description ?? "",
        tag: existingMenu.tag ?? "",
        target_audience: existingMenu.target_audience ?? "",
        price_per_person: existingMenu.price_per_person ?? 95000,
        image_url: existingMenu.image_url ?? "",
        banner_url: existingMenu.banner_url ?? "",
        category: existingMenu.category ?? "office",
        is_active: existingMenu.is_active ?? true,
        is_featured: existingMenu.is_featured ?? false,
        min_guests: existingMenu.min_guests ?? 10,
        nutrition_calories: existingMenu.nutrition_calories ?? 400,
        nutrition_protein: existingMenu.nutrition_protein ?? 30,
        nutrition_fat: existingMenu.nutrition_fat ?? 12,
        nutrition_carbs: existingMenu.nutrition_carbs ?? 45,
        meta_title: (existingMenu.seo_metadata as { meta_title?: string } | null)?.meta_title ?? "",
        meta_description: (existingMenu.seo_metadata as { meta_description?: string } | null)?.meta_description ?? "",
      });
      if (existingMenu.dishes?.length) setDishes(existingMenu.dishes as Dish[]);
      if (existingMenu.faqs?.length) setFaqs(existingMenu.faqs as FAQ[]);
    }
  }, [existingMenu]);

  const createMenu = useCreateMenu();
  const updateMenu = useUpdateMenu();

  const handleNameChange = (name: string) => {
    setForm((f) => ({ ...f, name, slug: isEdit ? f.slug : slugify(name) }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      ...form,
      dishes: dishes.filter((d) => d.name),
      faqs: faqs.filter((f) => f.q),
      seo_metadata: { meta_title: form.meta_title, meta_description: form.meta_description },
    };
    try {
      if (isEdit) {
        await updateMenu.mutateAsync({ id: id!, data: payload as Parameters<typeof updateMenu.mutateAsync>[0]["data"] });
        toast.success("Đã cập nhật menu");
      } else {
        await createMenu.mutateAsync({ data: payload as Parameters<typeof createMenu.mutateAsync>[0]["data"] });
        toast.success("Đã tạo menu mới");
      }
      navigate("/admin/menus");
    } catch {
      toast.error("Lỗi lưu menu");
    }
  };

  const isPending = createMenu.isPending || updateMenu.isPending;

  return (
    <AdminLayout>
      <div className="flex items-center gap-3 mb-6">
        <Link href="/admin/menus">
          <span className="p-2 bg-card border border-border rounded-xl hover:bg-muted/30 transition-colors cursor-pointer">
            <ChevronLeft className="w-4 h-4" />
          </span>
        </Link>
        <div>
          <h1 className="text-2xl font-black text-foreground">{isEdit ? "Chỉnh sửa menu" : "Tạo menu mới"}</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 max-w-3xl">
        {/* Basic Info */}
        <div className="bg-white rounded-2xl border border-border p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-foreground">Thông tin cơ bản</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-sm font-semibold mb-1.5">Tên menu *</label>
              <input value={form.name} onChange={(e) => handleNameChange(e.target.value)} required
                className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1.5">Slug</label>
              <input value={form.slug} onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))} required
                className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-mono" />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1.5">Danh mục</label>
              <select value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm">
                {categoryOptions.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1.5">Giá/người (đ) *</label>
              <input type="number" value={form.price_per_person} onChange={(e) => setForm((f) => ({ ...f, price_per_person: Number(e.target.value) }))} required
                className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1.5">Số lượng tối thiểu</label>
              <input type="number" value={form.min_guests} onChange={(e) => setForm((f) => ({ ...f, min_guests: Number(e.target.value) }))}
                className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1.5">Tag</label>
              <input value={form.tag} onChange={(e) => setForm((f) => ({ ...f, tag: e.target.value }))} placeholder="Eat Clean, Cao cấp..."
                className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1.5">Đối tượng</label>
              <input value={form.target_audience} onChange={(e) => setForm((f) => ({ ...f, target_audience: e.target.value }))}
                className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-semibold mb-1.5">Mô tả ngắn</label>
              <textarea value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} rows={2}
                className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm resize-none" />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-semibold mb-1.5">Mô tả chi tiết</label>
              <textarea value={form.long_description} onChange={(e) => setForm((f) => ({ ...f, long_description: e.target.value }))} rows={4}
                className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm resize-none" />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-semibold mb-1.5">URL ảnh thumbnail</label>
              <input value={form.image_url} onChange={(e) => setForm((f) => ({ ...f, image_url: e.target.value }))}
                className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-semibold mb-1.5">URL banner</label>
              <input value={form.banner_url} onChange={(e) => setForm((f) => ({ ...f, banner_url: e.target.value }))}
                className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
            </div>
            <div className="flex items-center gap-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.is_active} onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))} className="accent-primary" />
                <span className="text-sm font-medium">Hiển thị</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.is_featured} onChange={(e) => setForm((f) => ({ ...f, is_featured: e.target.checked }))} className="accent-primary" />
                <span className="text-sm font-medium">Nổi bật</span>
              </label>
            </div>
          </div>
        </div>

        {/* Dishes */}
        <div className="bg-white rounded-2xl border border-border p-6 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-foreground">Món ăn trong menu</h3>
            <button type="button" onClick={() => setDishes([...dishes, { name: "", description: "" }])}
              className="flex items-center gap-1.5 text-sm text-primary font-semibold hover:underline">
              <Plus className="w-3.5 h-3.5" />Thêm món
            </button>
          </div>
          {dishes.map((dish, i) => (
            <div key={i} className="flex gap-3 items-start">
              <div className="flex-1 grid grid-cols-2 gap-2">
                <input value={dish.name} onChange={(e) => { const d = [...dishes]; d[i].name = e.target.value; setDishes(d); }} placeholder="Tên món"
                  className="px-3 py-2 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
                <input value={dish.description} onChange={(e) => { const d = [...dishes]; d[i].description = e.target.value; setDishes(d); }} placeholder="Mô tả"
                  className="px-3 py-2 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
              </div>
              <button type="button" onClick={() => setDishes(dishes.filter((_, j) => j !== i))} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {/* Nutrition */}
        <div className="bg-white rounded-2xl border border-border p-6 shadow-sm">
          <h3 className="font-bold text-foreground mb-4">Dinh dưỡng (mỗi suất)</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[["nutrition_calories", "Calories (kcal)"], ["nutrition_protein", "Protein (g)"], ["nutrition_fat", "Chất béo (g)"], ["nutrition_carbs", "Carbs (g)"]].map(([key, label]) => (
              <div key={key}>
                <label className="block text-xs font-semibold mb-1.5 text-muted-foreground">{label}</label>
                <input type="number" value={form[key as keyof typeof form] as number}
                  onChange={(e) => setForm((f) => ({ ...f, [key]: Number(e.target.value) }))}
                  className="w-full px-3 py-2 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
              </div>
            ))}
          </div>
        </div>

        {/* FAQs */}
        <div className="bg-white rounded-2xl border border-border p-6 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-foreground">FAQs</h3>
            <button type="button" onClick={() => setFaqs([...faqs, { q: "", a: "" }])}
              className="flex items-center gap-1.5 text-sm text-primary font-semibold hover:underline">
              <Plus className="w-3.5 h-3.5" />Thêm FAQ
            </button>
          </div>
          {faqs.map((faq, i) => (
            <div key={i} className="flex gap-3 items-start">
              <div className="flex-1 space-y-2">
                <input value={faq.q} onChange={(e) => { const f = [...faqs]; f[i].q = e.target.value; setFaqs(f); }} placeholder="Câu hỏi"
                  className="w-full px-3 py-2 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
                <textarea value={faq.a} onChange={(e) => { const f = [...faqs]; f[i].a = e.target.value; setFaqs(f); }} placeholder="Câu trả lời" rows={2}
                  className="w-full px-3 py-2 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm resize-none" />
              </div>
              <button type="button" onClick={() => setFaqs(faqs.filter((_, j) => j !== i))} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {/* SEO */}
        <div className="bg-white rounded-2xl border border-border p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-foreground">SEO</h3>
          <div>
            <label className="block text-sm font-semibold mb-1.5">Meta Title</label>
            <input value={form.meta_title} onChange={(e) => setForm((f) => ({ ...f, meta_title: e.target.value }))}
              className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-semibold mb-1.5">Meta Description</label>
            <textarea value={form.meta_description} onChange={(e) => setForm((f) => ({ ...f, meta_description: e.target.value }))} rows={2}
              className="w-full px-4 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm resize-none" />
          </div>
        </div>

        <div className="flex gap-3">
          <button type="submit" disabled={isPending}
            className="flex items-center gap-2 bg-primary text-white px-8 py-3 rounded-xl font-bold hover:bg-primary/90 disabled:opacity-60 transition-colors">
            {isPending ? <><Loader2 className="w-4 h-4 animate-spin" />Đang lưu...</> : (isEdit ? "Cập nhật menu" : "Tạo menu")}
          </button>
          <Link href="/admin/menus">
            <span className="px-8 py-3 rounded-xl font-bold border border-border text-muted-foreground hover:bg-muted/30 transition-colors cursor-pointer block">Hủy</span>
          </Link>
        </div>
      </form>
    </AdminLayout>
  );
}
